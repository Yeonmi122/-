var num1 = prompt("첫 번째 수: ");
var num2 = prompt("두 번째 수: ");
var sum = parseInt(num1) + parseInt(num2);

document.write(num1+"과"+num2+"를 더하면 <br>");
document.write(sum+"입니다.");