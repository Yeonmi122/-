<?php
    $name = $_POST["name"];
    $nickname = $_POST["nickname"];
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    $address = $_POST["address"];
    $address_detailed = $_POST["address2"];

    $con = mysqli_connect("localhost", "w1004mesmg", "sunmoons1s2s3!", "w1004mesmg");

    $sql = "insert into ym_member(name,nickname,email,pass,address,address_detailed)";

    $sql .= "values('$name','$nickname','$email','$pass','$address','$address_detailed')";

    mysqli_query($con,$sql);
    mysqli_close($con);

    echo"<script>
            location.href = '/p2/yym/project_youja/login.php';
        </script>";
    

    
?>

      
