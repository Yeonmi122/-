<?php
    $num = $_GET["num"];

    $name = $_POST["name"];
    $langue = $_POST["lang"];
    $url = $_POST["url"];
    $info = $_POST["info"];

    $info = htmlspecialchars($info,ENT_QUOTES);

    $con = mysqli_connect("localhost","yeonmi","1234","youja");

    $sql = "insert into mypage (name,langue,url,part,info)";
    $sql = "values('$name','$langue','$url','$part','$info')";

    mysqli_query($con,$sql);

    mysqli_close($con);

    echo "<script>
        location.href = 'profile_view.php';
        </script>"; 
?>

<?php include $_SERVER['DOCUMENT_ROOT']."/PROJECT_YOUJA/h.php"?>

<?php
	$num = $_GET["num"];

    $name = $_POST["name"];
    $lang = $_POST["lang"];
    $url = $_POST["url"];
    $info = $_POST["info"];

	$subject = htmlspecialchars($subject, ENT_QUOTES);	// 제목 HTML 특수문자 변환
	$content = htmlspecialchars($content, ENT_QUOTES);	// 내용 HTML 특수문자 변환 
	$regist_day = date("Y-m-d (H:i)");  // UTC 기준 현재의 '년-월-일 (시:분)'

	$con = mysqli_connect("localhost", "yeonmi", "1234", "youja");	// DB 연결
	$sql = "update mypage set name='$name', lang='$lang', url = '$url', info='$info', ";	// 수정 명령
	mysqli_query($con, $sql);  // SQL 명령 실행

	mysqli_close($con);       // DB 연결 끊기

	echo "
	   <script>
	    location.href = 'profile_view.php';
	   </script>
	";
?>
<?php include $_SERVER['DOCUMENT_ROOT']."./PROJECT_YOUJA/f.php"?>