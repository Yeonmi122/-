<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel = "stylesheet" href="sign_up.css">
  <title>sign_up</title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
  <div class="container">
    <div class="input-form-backgroud row">
      <div class="input-form col-md-12 mx-auto">
        <h4 class="mb-3">마이페이지</h4>
        <form class="validation-form" name = "int" method="post" action="profile_insert.php">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="name">이름</label>
              <input type="text" class="form-control" name = "name" id="name" placeholder="" value="" required>
              <div class="invalid-feedback">
                이름을 입력해주세요.
              </div>
          <div class="mb-3">
            <label for="lang">언어시험 성적(자격증)</label>
            <input type="" class="form-control" name = "lang" id="lang" placeholder="자격증" required>
            <div class="invalid-feedback">
              언어시험 성적(자격증)을 입력해주세요.
            </div>
          </div>
          <div class="mb-3">
            <label for="url">유튜브 채널</label>
            <input type="url" class="form-control" name = "url" id="url" placeholder="url" required>
            <div class="invalid-feedback">
              유튜브 채널을  입력해주세요.
            </div>
          </div>
          <div class="mb-3">
            <label for="infpo">상세 정보</label>
            <input type="text" class="form-control" name = "info" id="info" placeholder="경력 사항을 자세하게 써주세요" required>
            <div class="invalid-feedback">
              상세 정보 입력해주세요.
            </div>
          </div>
          <div class="mb-4"></div>
          <button class="btn btn-primary btn-lg btn-block" type="submit" id = sign onclick="check_input()">가입 완료</button>
        </form>
      </div>
    </div>
    <footer  class="my-3 text-center text-small">
      <a href = "index.php"><img src = "./img/logo_2.png" width ="100rem"></a>
    </footer>
  </div>
  <script>
    window.addEventListener('load', () => {
      const forms = document.getElementsByClassName('validation-form');

      Array.prototype.filter.call(forms, (form) => {
        form.addEventListener('submit', function (event) {
          if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
          }

          form.classList.add('was-validated');
        }, false);
      });
    }, false);
  </script>
</body>
</html>
