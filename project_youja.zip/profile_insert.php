<?php
    $name = $_POST["name"];
    $lang = $_POST["lang"];
    $url = $_POST["url"];
    $info = $_POST["info"];

	$info = htmlspecialchars($info, ENT_QUOTES);	// 내용 HTML 특수문자 변환

	$con = mysqli_connect("localhost", "yeonmi", "1234", "youja");	// DB 연결

	$sql = "insert into mypage (name,lang,url,info) ";	// 레코드 삽입 명령
	$sql .= "values('$name','$lang','$url','$info')";

	mysqli_query($con, $sql);  // $sql에 저장된 명령 실행

	mysqli_close($con);       // DB 연결 끊기

	// 목록 페이지로 이동
	echo "<script>
	    location.href = 'profile_view.php';
	   </script>";
?>

  
